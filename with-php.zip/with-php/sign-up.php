<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    use PHPMailer\PHPMailer\SMTP;

    $dbconn = include '_layout/_dbconnection.php';
    if ($dbconn) {}else{ header("Location: 404");}
    
    $message = [];

    session_start();

    if (isset($_SESSION['loggedin'])) {
        header('Location: /');    
    }
   
    if (isset($_POST["create-account"])) {
        
            $username = "user-".mt_rand(0000000,9999999);
            $firstname = trim($_POST["firstname"]);
            $lastname = trim($_POST["lastname"]);
            $emailaddress = trim($_POST["email"]);
            $phonenumber = trim($_POST["phone"]);
            $password = trim($_POST["password"]);
            $sess_password = trim(htmlspecialchars(strip_tags($password)));
            $token = bin2hex(random_bytes(22)).mt_rand(0000000,9999999).bin2hex(random_bytes(4));

            $terms = true;
            
            if (isset($_POST["newslettter"])) {
                $newslettter = true;
            }else{
                $newslettter = false;
            }
            
            # filter strings
            $firstname = htmlspecialchars(strip_tags($firstname));
            $lastname = htmlspecialchars(strip_tags($lastname));
            $emailaddress = htmlspecialchars(strip_tags($emailaddress));
            $phonenumber = htmlspecialchars(strip_tags($phonenumber));
            $password = md5(sha1(htmlspecialchars(strip_tags($password))));
            

            # activation link
            $hashedEmail = md5($emailaddress);
            $activationLink = "https://simganic.com/activate-account?e=$hashedEmail&token=$token";
            
            $CheckIfUserExist = "SELECT * FROM _users WHERE _email = '$emailaddress'";
            $UserExist = $con->query($CheckIfUserExist);
            if ($UserExist->num_rows > 0) {
                # user exist
                array_push($message, "Email Address Already Exists.");
            }else{
                # no errors add user
                $AddNewUser = "INSERT INTO _users (_firstname, _lastname, _username, _email, _phone, _password, _newsletter, _currency, _language, _token, isverified) VALUES ('$firstname', '$lastname', '$username', '$emailaddress', '$phonenumber', '$password', '$newslettter', 'NGN', 'ENG', '$token', false)";
                $UserAdded = $con->query($AddNewUser);

                if ($UserAdded) {
                    array_push($message, "Registeration Complete.");
                    # user added  
                    $usr = $firstname.' '.$lastname;
                    # send mail
                    include '_layout/_mails.php';
                    
                    $mail->setFrom("support@simganic.com", "SimGanic");
                    $mail->addReplyTo("support@simganic.com", "SimGanic");
                    $mail->addAddress($emailaddress, $usr); # name is optional
                    #$mail->addCC('info@tedmaniatv.com', 'Elena');
                    #$mail->addBCC('etiketochukwu@gmail.com', 'Alex');
                    
                    $mail->Subject = $subject;
                    $mail->isHTML(true);
                    
                    #mail dependencies
                    $web = "https://simganic.com/";
                    $confirm_email = '
                        <!DOCTYPE html>
                        <html>
                        <head>
                            <title>Mail</title>

                            <!-- CSS Libraries -->
                            <link rel="stylesheet" href="'.$web.'assets/modules/bootstrap/css/bootstrap.min.css">
                            <link rel="stylesheet" href="'.$web.'assets/modules/fontawesome/css/all.min.css">
                            <link rel="stylesheet" href="'.$web.'assets/fonts/font-awesome-6/css/all.css">

                            <!-- Template CSS -->
                            <link rel="stylesheet" href="'.$web.'assets/css/style.min.css">
                            <link rel="stylesheet" href="'.$web.'assets/css/components.min.css">
                            <link rel="stylesheet" href="'.$web.'assets/css/mystyle.css">
                            <link rel="stylesheet" href="'.$web.'assets/css/mails.css">
                        </head>
                        <body>
                            <div class="content bg-light">
                                <div class="logo">
                                    
                                </div>
                                <div class="content-body">
                                    <h5 class="content-header-text">Welcome, '.ucwords($firstname).'!</h5>
                                    <h6>You’re Almost There,</h6>
                                    <div>An account was just created at <a href="">simganic.com</a> with this email address. Before we proceed, we need to confirm this request came from you, so if it did then kindly click the link below to confirm your account.</div>
                                    <a href="'.$activationLink.'" class="btn btn-primary">Confirm My Account <i class="fa fa-arrow-right"></i></a>
                                    <div>Please note that unverified accounts are <strong>automatically deleted</strong> 30days after sign up.</div>
                                    <strong>PS:</strong> if you did not sign up at <a href="">simganic.com</a>, send a report to <a href="mailto:reports@simganic.com">reports@simganic.com</a> to block the account.
                                    <hr>
                                    <div class="text-right">
                                        <div>Thanks,</div>
                                        <a href="mailto:support@simganic.com">support@simganic.com</a>
                                        <div class="content-footer">
                                        <a href=""><i class="fa-brands fa-facebook"></i></a> 
                                        <a href=""><i class="fa-brands fa-whatsapp"></i></a> 
                                        <a href=""><i class="fa-brands fa-instagram"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </body>
                        </html>
                    ';
                    $mail->Body = $confirm_email;
                    $mail->AltBody = $message;
                    
                    $mail->send();
                    if($mail->send()){
                        array_push($message, "Login To Email Account To Confirm Your Email Address.");
                    }else{ 
                        array_push($message, "Error 501! Message could not be sent. Mailer Error: {$mail->ErrorInfo}. Contact SimGanic Admin @ <a href='mailto:support@simganic.com'>support@simganic.com</a>");
                    }

                    //$_SESSION['login_email'] = $emailaddress;
                    $_SESSION['login_password'] = $sess_password;
                    //header("Location: sign-in");
                }
            }
    }

?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
<title>Create Your Account - SimGanic</title>

<!-- General CSS Files -->
<link rel="stylesheet" href="assets/modules/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/modules/fontawesome/css/all.min.css">
<link rel="stylesheet" href="assets/fonts/font-awesome-6/css/all.css">

<!-- CSS Libraries -->

<!-- Template CSS -->
<link rel="stylesheet" href="assets/css/style.min.css">
<link rel="stylesheet" href="assets/css/components.min.css">
<link rel="stylesheet" href="assets/css/mystyle.css">
</head>

<body class="layout-1">
<!-- Page Loader -->
<div class="page-loader-wrapper">
    <span class="loader"><span class="loader-inner"></span></span>
</div>

<div id="app">
    <div class="main-wrapper main-wrapper-1">
        <div class="navbar-bg"></div>
        
        <?php include '_layout/_header_sidebar.php';?>
        
        <!-- Start app main Content -->
        <div class="main-content">
            <section class="section">
                <div class="section-header">
                    <h1>Sign In To Your SimGanic Account</h1>
                </div>

                <div class="section-body">
                    <div class="card" id="sample-login">
                        <form method="post" action="">
                            <div class="card-body pb-0">
                                <?php if (count($message) > 0) : ?>
                                <div class="alert-div">
                                <?php foreach ($message as $error) : ?>
                                    <div class="alert alert-primary alert-dismissible show fade">
                                        <div class="alert-body">
                                            <button class="close" data-dismiss="alert"><span>×</span></button>
                                            <?php echo $error ?>
                                        </div>
                                    </div>
                                <?php endforeach ?>
                                </div>
                                <?php endif ?>
                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label>FirstName *</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                    <i class="fas fa-user"></i>
                                                </div>
                                            </div>
                                            <input type="text" class="form-control" name="firstname" placeholder="Enter FirstName" required>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>LastName *</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                    <i class="fas fa-user"></i>
                                                </div>
                                            </div>
                                            <input type="text" class="form-control" name="lastname" placeholder="Enter LastName" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label>Email Address *</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                    <i class="fas fa-envelope"></i>
                                                </div>
                                            </div>
                                            <input type="email" class="form-control" name="email" placeholder="Enter Email Address" required>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                    <label>Phone Number *</label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text">
                                                <i class="fas fa-phone"></i>
                                            </div>
                                        </div>
                                        <input type="number" class="form-control" name="phone" placeholder="Enter Phone Number..." required>
                                    </div>
                                </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label>Password  *</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                    <i class="fas fa-lock"></i>
                                                </div>
                                            </div>
                                            <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password" required>
                                            <div class="input-group-append" title data-toggle="tooltip" data-placement="left" data-original-title="Toggle Password Visibility">
                                                <div class="input-group-text">
                                                    <i class="fa fa-eye eye-fa"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>Confirm Password *</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                    <i class="fas fa-lock"></i>
                                                </div>
                                            </div>
                                            <input type="password" class="form-control" id="pass-confirm" name="confirm-password" placeholder="Confirm Password" required>
                                            <div class="input-group-append" title data-toggle="tooltip" data-placement="left" data-original-title="Toggle Password Visibility">
                                                <div class="input-group-text">
                                                    <i class="fa fa-eye eye-fa"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" name="csrfToken" value="">
                                <br>
                                        <label for="terms-and-pivacy-policy">I Accept SimGanic <a href="terms-and-conditions" target="_blank">Terms and Conditions</a> &amp; <a href="privacy-policy" target="_blank">Privacy Policy</a></label>
                                 
                                    <div class="">
                                        <input type="checkbox" name="newslettter" checked="">
                                        <label for="newsletter">Sign Me Up For Newsletters and Notifications</label>
                                    </div>
                            </div>
                            <div class="card-footer pt-">
                                <button type="submit" name="create-account" class="btn btn-primary btn btn-form">Create Account</button>
                                <a href="sign-in" class="ml-2">Already Have An Account, Login?</a>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
        <style>
            .btn-form{
                text-transform: uppercase;
                font-weight: bolder;
                letter-spacing: 2px;
                padding: 10px 15px;
            }
            .see{
                position: absolute;
                right: 3px;
                top: 3px;
                font-size: 20px;
                margin: auto;
            }
            .input-group-append{
                cursor: pointer;
            }
        </style>

        <!-- Start app Footer part -->
        <?php include '_layout/_footer.php';?>
    </div>
</div>

<!-- General JS Scripts -->
<script src="assets/bundles/lib.vendor.bundle.js"></script>
<script src="js/CodiePie.js"></script>

<!-- JS Libraies -->

<!-- Page Specific JS File -->
<script>
    $(".input-group-append").click(function(){
        var x = document.getElementById("password");
        var y = document.getElementById("pass-confirm");
        if (x.type === "password") {
            x.type = "text";
            y.type = "text";
            $(".eye-fa").removeClass("fa-eye");
            $(".eye-fa").addClass("fa-eye-slash");
        } else {
            x.type = "password";
            y.type = "password";
            $(".eye-fa").addClass("fa-eye");
            $(".eye-fa").removeClass("fa-eye-slash");
        }
    });

    var message = $('.alert-body').text();
    var messageBox = $('.alert-div');
    if (message != "" || message != null) {
        setTimeout(hideMsg, 3000);
    }
    function hideMsg() {
        message = "";
        messageBox.fadeOut(500);
    }
</script>
<!-- Template JS File -->
<script src="js/scripts.js"></script>
<script src="js/custom.js"></script>
</body>

<!-- blank.html  Tue, 07 Jan 2020 03:35:42 GMT -->
</html>