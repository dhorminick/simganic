<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    use PHPMailer\PHPMailer\SMTP;

    session_start();

    if (!isset($_SESSION['loggedin'])) {
    }else{
        header("Location: update-account-password");
        exit();
    }
    //dbconn
    $dbconn = include '_layout/_dbconnection.php';
    if ($dbconn) {}else{ header("Location: 404");}

    $message = [];
    # echo md5(sha1("test"));
    
    if (isset($_POST["reset-password"])) {
        $email = strip_tags(trim(htmlspecialchars($_POST["email"])));
        
        $CheckIfUserExist = "SELECT * FROM _users WHERE _email = '$email'";
        $UserExist = $con->query($CheckIfUserExist);
        if ($UserExist->num_rows > 0) {
            $row = mysqli_fetch_array($UserExist);

            $token = bin2hex(random_bytes(22)).mt_rand(0000000,9999999).bin2hex(random_bytes(4));
            $reset_link = "https://simganic.com/reset-password?e=$email&token=$token";
            $website = "https://simganic.com/";
            $usr_password = $row["_password"];

            $UpdateUser = "UPDATE _users SET _password = '$token' WHERE _email = '$email' AND _password = '$usr_password'";
            $IsUserUpdated = $con->query($UpdateUser);

            if ($IsUserUpdated) {
                # send mail
                include '_layout/_mails.php';
                
                $mail->setFrom("support@simganic.com", "SimGanic");
                $mail->addReplyTo("support@simganic.com", "SimGanic");
                $mail->addAddress($email); # name is optional
                #$mail->addCC('info@tedmaniatv.com', 'Elena');
                #$mail->addBCC('etiketochukwu@gmail.com', 'Alex');

                $mail->Subject = "Reset Your SimGanic Account Password.";
                $mail->isHTML(true);

                $reset_email = '
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <title>Mail</title>

                        <!-- CSS Libraries -->
                        <link rel="stylesheet" href="'.$web.'assets/modules/bootstrap/css/bootstrap.min.css">
                        <link rel="stylesheet" href="'.$web.'assets/modules/fontawesome/css/all.min.css">
                        <link rel="stylesheet" href="'.$web.'assets/fonts/font-awesome-6/css/all.css">

                        <!-- Template CSS -->
                        <link rel="stylesheet" href="'.$web.'assets/css/style.min.css">
                        <link rel="stylesheet" href="'.$web.'assets/css/components.min.css">
                        <link rel="stylesheet" href="'.$web.'assets/css/mystyle.css">
                        <link rel="stylesheet" href="'.$web.'assets/css/mails.css">
                    </head>
                    <body>
                        <div class="content bg-light">
                            <div class="logo">
                                
                            </div>
                            <div class="content-body">
                                <h5 class="content-header-text">Reset You SimGanic Account Password,</h5>
                                <div>
                                    <p><strong>Hi <?php echo ucwords($_SESSION["lastname"]); ?>,</strong></p>
                                </div>
                                <div>A request to reset <strong>"'.$email.'"</strong> <a href="'.$website.'">simganic</a> account password was just sent. Before we proceed, we need to confirm this request came from you, so if it did then kindly click the link below to reset your password.</div>
                                <a href="'.$reset_link.'" class="btn btn-primary">Reset My Password <i class="fa fa-arrow-right"></i></a>
                                <div><strong>PS:</strong> if you did not request a reset of your account password, send a report to <a href="mailto:reports@simganic.com">reports@simganic.com</a> to cancel the request.</div>
                                <hr>
                                <div class="text-right">
                                    <div>SimGanic,</div>
                                    <a href="mailto:support@simganic.com">support@simganic.com</a>
                                    <div class="content-footer">
                                    <a href=""><i class="fa-brands fa-facebook"></i></a> 
                                    <a href=""><i class="fa-brands fa-whatsapp"></i></a> 
                                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </body>
                    </html>
                ';
                
                $mail->Body = $reset_email;
                $mail->AltBody = $reset_email;
                
                $mail->send();
                if($mail->send()){
                    array_push($message, "<i class='fa fa-check'></i> A Reset Link Has Been Sent To '$email'.");
                }else{ 
                    array_push($message, "<i class='fa fa-cancel'></i> Error 501! Reset link could not be sent. Mailer Error: {$mail->ErrorInfo}");
                }
            }else{
                array_push($message, "<i class='fa fa-cancel'></i> Error 501! Server Error.");
            }
        }else{
            array_push($message, "<i class='fa fa-cancel'></i> Email Address Doesn't Exist."); 
        }
        
    }

?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
<title>Reset Account Password - SimGanic</title>

<!-- General CSS Files -->
<link rel="stylesheet" href="assets/modules/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/modules/fontawesome/css/all.min.css">
<link rel="stylesheet" href="assets/fonts/font-awesome-6/css/all.css">

<!-- CSS Libraries -->

<!-- Template CSS -->
<link rel="stylesheet" href="assets/css/style.min.css">
<link rel="stylesheet" href="assets/css/components.min.css">
<link rel="stylesheet" href="assets/css/mystyle.css">
</head>

<body class="layout-1">
<!-- Page Loader -->
<div class="page-loader-wrapper">
    <span class="loader"><span class="loader-inner"></span></span>
</div>

<div id="app">
    <div class="main-wrapper main-wrapper-1">
        <div class="navbar-bg"></div>
        
        <?php include '_layout/_header_sidebar.php';?>
        
        <!-- Start app main Content -->
        <div class="main-content">
            <section class="section">
                <div class="section-header">
                    <h5>Update Account Password</h5>
                </div>

                <div class="section-body">
                    <div class="card-body">
                    <form method="post" action="">
                        <?php if (count($message) > 0) : ?>
                            <div class="alert-div">
                                <?php foreach ($message as $error) : ?>
                                <div class="alert alert-primary alert-dismissible show fade">
                                    <div class="alert-body">
                                        <button class="close" data-dismiss="alert"><span>×</span></button>
                                        <?php echo $error ?>
                                    </div>
                                </div>
                                <?php endforeach ?>
                            </div>
                        <?php endif ?>
                        <?php 
                            if (isset($_GET["token"]) && isset($_GET["e"]) && $_GET["token"] != null && $_GET["e"] != null) {
                                $mailed_usr_email = trim(strip_tags(htmlspecialchars($_GET["e"])));
                                $mailed_usr_token = trim(strip_tags(htmlspecialchars($_GET["token"])));

                                if (isset($_POST["update"])) {
                                    $new_password = strip_tags(trim($_POST["new-password"]));
                                    $confirm_password = strip_tags(trim($_POST["confirm-password"]));

                                    if ($new_password != $confirm_password) {
                                        array_push($message, "Error 402! Passwords Don't Match.");
                                    }else{
                                        $CheckIfUserExist = "SELECT * FROM _users WHERE _email = '$mailed_usr_email' AND _password = '$mailed_usr_token'";
                                        $UserExist = $con->query($CheckIfUserExist);
                                        if ($UserExist->num_rows > 0) {
                                            //passwords match, hash it
                                            $new_password = md5(sha1($new_password));
                                            $UpdateUser = "UPDATE _users SET _password = '$new_password', isverified = true WHERE _email = '$mailed_usr_email' AND _password = '$mailed_usr_token'";
                                            $IsUserUpdated = $con->query($UpdateUser);

                                            if ($IsUserUpdated) {
                                                array_push($message, "<i class='fa fa-check'></i> Account password reset successfully! Redirecting to sign in page.");
                                                $_SESSION["reset-email"] = $mailed_usr_email;
                                                $_SESSION["reset-password"] = $new_password;
                                                echo "setTimeout(function(){ <script>window.location.assign('sign-in');</script> }, 4000);";
                                            }else{
                                                array_push($message, "<i class='fa fa-cancel'></i> Error 401! Password Error.");
                                            }
                                        }else{
                                            array_push($message, "<i class='fa fa-cancel'></i> Error 402! Account Email And Token Error.");
                                        }
                                    }
                                }

                                $CheckIfUserExist = "SELECT * FROM _users WHERE _email = '$mailed_usr_email' AND _password = '$mailed_usr_token'";
                                $UserExist = $con->query($CheckIfUserExist);
                                if ($UserExist->num_rows > 0) {
                        ?>
                        <div class="form-group">
                            <label for="inputAddress2">New Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="n-p" name="new-password" value="" placeholder="Enter New Password...">
                                <div class="input-group-append" title data-toggle="tooltip" data-placement="left" data-original-title="Toggle Password Visibility">
                                    <div class="input-group-text">
                                        <i class="fa fa-eye eye-fa"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputAddress2">Confirm New Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="c-p" name="confirm-password" value="" placeholder="Retype New Password...">
                                <div class="input-group-append" title data-toggle="tooltip" data-placement="left" data-original-title="Toggle Password Visibility">
                                    <div class="input-group-text">
                                        <i class="fa fa-eye eye-fa"></i>
                                    </div>
                                </div>
                            </div><br>
                            <span style="font-size: 15px;color:red;" id="errorMessage"></span>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-update-s" name="update">Update Password</button>
                        </div>
                        <?php }else{ ?>
                        <script>alert('Error 402! Reset Details Error.')</script>
                        <div class='col-12 w_main'>
                            <center>
                            <div class='w_icon'>
                                <i class='fa fa-cancel' style='transform:none !important;'></i>
                            </div><br>
                            <h3>Oops!! Nothing To Show Here.</h3>
                            <p></p>
                            <a href='sign-in' class='csp'>
                                <button class='btn btn-primary btn-update-s'><i class='fa fa-arrow-left'></i> Sign In</button>
                            </a>
                            </center>
                        </div>
                        <style>.section-header{display:none !important;}</style>
                        <?php }}else{ ?>
                        <div class="form-group">
                            <label for="inputAddress">Email Address:</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fas fa-envelope"></i>
                                    </div>
                                </div>
                                <input type="email" class="form-control"  name="email" placeholder="Enter Email Address...">
                            </div>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-update-s" name="reset-password">Send Reset Link <i class="fa fa-arrow-right"></i></button>
                        </div>
                        <?php } ?>
                        <style>
                            .btn-update-s {
                                font-weight: bolder;
                                letter-spacing: 1px !important;
                            }
                        </style>
                    </form>
                    </div>
                </div>
            </section>
        </div>
        <style>
        
        </style>

        <!-- Start app Footer part -->
        <?php include '_layout/_footer.php';?>
    </div>
</div>

<!-- General JS Scripts -->
<script src="assets/bundles/lib.vendor.bundle.js"></script>
<script src="js/CodiePie.js"></script>

<!-- JS Libraies -->

<!-- Page Specific JS File -->
<script>
    $(".input-group-append").click(function(){
        var x = document.getElementById("n-p");
        var y = document.getElementById("c-p");
        if (x.type === "password") {
            x.type = "text";
            y.type = "text";
            $(".eye-fa").removeClass("fa-eye");
            $(".eye-fa").addClass("fa-eye-slash");
        } else {
            x.type = "password";
            y.type = "password";
            $(".eye-fa").addClass("fa-eye");
            $(".eye-fa").removeClass("fa-eye-slash");
        }
    });
</script>

<!-- Template JS File -->
<script src="js/scripts.js"></script>
<script src="js/custom.js"></script>
</body>

</html>