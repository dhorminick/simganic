<?php
	$page_product_category = "Flour";
	include $_SERVER['DOCUMENT_ROOT'].'/_layout/single-category.php';
?>