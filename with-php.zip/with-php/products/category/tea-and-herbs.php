<?php
	$page_product_category = "Tea and Herbs";
	include $_SERVER['DOCUMENT_ROOT'].'/_layout/single-category.php';
?>