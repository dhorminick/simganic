<?php
	$page_product_category = "Dairy";
	include $_SERVER['DOCUMENT_ROOT'].'_layout/single-category.php';
?>