<?php
	$page_product_category = "Extracts and Flavours";
	include $_SERVER['DOCUMENT_ROOT'].'/_layout/single-category.php';
?>