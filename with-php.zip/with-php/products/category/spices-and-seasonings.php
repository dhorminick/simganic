<?php
	$page_product_category = "Spices and Seasonings";
	include $_SERVER['DOCUMENT_ROOT'].'/_layout/single-category.php';
?>