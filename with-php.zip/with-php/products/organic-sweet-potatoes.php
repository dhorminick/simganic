<?php
	$page_product_id = "#PD-D06D43207087128";

	include '_layout/single-product.php';
?>