<?php
	$page_product_id = "#PD-B02C91F81812485";

	include '_layout/single-product.php';
?>