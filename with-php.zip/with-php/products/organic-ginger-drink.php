<?php
	$page_product_id = "#PD-5C56E017D393195";

	include '_layout/single-product.php';
?>