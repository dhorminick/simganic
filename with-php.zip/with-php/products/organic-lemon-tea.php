<?php
	$page_product_id = "#PD-980252DA7E43898";

	include '_layout/single-product.php';
?>