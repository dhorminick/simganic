<?php
    $user_selected_currency_conversion_to_naira_rate = "1";
    $user_selected_currency_symbol = "&#8358;";
?>