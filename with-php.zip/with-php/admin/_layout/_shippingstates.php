<option disabled="" value="1">Abia</option>
                                    <option disabled="" value="Adamawa">Adamawa</option>
                                    <option disabled="" value="Akwa-Ibom">Akwa Ibom</option>
                                    <option disabled="" value="Anambra">Anambra</option>
                                    <option disabled="" value="Bauchi">Bauchi</option>
                                    <option disabled="" value="Bayelsa">Bayelsa</option>
                                    <option disabled="" value="Benue">Benue</option>
                                    <option disabled="" value="Borno">Borno</option>
                                    <option disabled="" value="Cross-River">Cross River</option>
                                    <option disabled="" value="Delta">Delta</option>
                                    <option disabled="" value="Ebonyi">Ebonyi</option>
                                    <option disabled="" value="Edo">Edo</option>
                                    <option disabled="" value="Ekiti">Ekiti</option>
                                    <option disabled="" value="Enugu">Enugu</option>
                                    <option disabled="" value="15">Federal Capital Territory</option>
                                    <option disabled="" value="Gombe">Gombe</option>
                                    <option disabled="" value="Imo">Imo</option>
                                    <option disabled="" value="Jigawa">Jigawa</option>
                                    <option disabled="" value="Kaduna">Kaduna</option>
                                    <option disabled="" value="Kano">Kano</option>
                                    <option disabled="" value="Kebbi">Kebbi</option>
                                    <option disabled="" value="Kogi">Kogi</option>
                                    <option disabled="" value="Kwara">Kwara</option>
                                    <option value="Lagos" selected="">Lagos</option>
                                    <option disabled="" value="Nasarawa">Nasarawa</option>
                                    <option disabled="" value="Niger">Niger</option>
                                    <option disabled="" value="Ogun">Ogun</option>
                                    <option disabled="" value="Ondo">Ondo</option>
                                    <option disabled="" value="Osun">Osun</option>
                                    <option disabled="" value="Oyo">Oyo</option>
                                    <option disabled="" value="Plateau">Plateau</option>
                                    <option disabled="" value="Rivers">Rivers</option>
                                    <option disabled="" value="Sokoto">Sokoto</option>
                                    <option disabled="" value="Yobe">Yobe</option>