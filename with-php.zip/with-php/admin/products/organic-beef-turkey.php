<?php
	$page_product_id = "#PD-B7814F5AA556535";

	include "_layout/single-product.php";
?>